package app;

public class productConfig {
    //Data URL
    public static final String DATA_URL = "http://192.168.1.2/android_login_api/product.php?page=";

    //JSON TAGS
    public static final String TAG_IMAGE_URL = "image";
    public static final String TAG_NAME = "name";
    public static final String TAG_PUBLISHER = "description";
}
